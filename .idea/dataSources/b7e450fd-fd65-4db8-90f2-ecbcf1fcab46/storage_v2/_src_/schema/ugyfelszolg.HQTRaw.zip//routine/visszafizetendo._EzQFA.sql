create
    definer = root@localhost function visszafizetendo(cikk char(10), gysz char(20)) returns decimal
    RETURN (select ár from CSERE cs, ELADÁS ea
			where ea.cikkszám=cs.cikkszám and ea.gyártsz=cs.gyártsz 
			and cs.cikkszám=cikk and cs.új_gyártsz=gysz);

