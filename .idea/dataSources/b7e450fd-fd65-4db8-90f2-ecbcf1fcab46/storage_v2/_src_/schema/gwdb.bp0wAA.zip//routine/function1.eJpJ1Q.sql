create
    definer = root@localhost function function1(maximum int) returns int
    RETURN(
SELECT MAX(score) FROM guitarwars
);

